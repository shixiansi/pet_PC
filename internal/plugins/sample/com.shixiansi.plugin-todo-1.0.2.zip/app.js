// The todo plugin (1.0.0).
//
// It is a plain module in a sandboxed iframe: it can address exactly one thing in the outside
// world, its parent, and only with the message types of the bridge protocol (ready / init /
// request / response / event). No fetch, no localStorage, no file access - the host's `storage`
// capability is where the list lives.
//
// ONE document, TWO jobs, and the host mounts it twice:
//
//   surface.kind === 'surface'                  the list, in the column beside the pet
//   surface.kind === 'panel' + slot 'background' a HEADLESS frame that only runs the reminders
//
// The second one exists because a reminder has to fire while no interface is open, and the host
// only delivers events to a frame it mounted. It draws nothing (`body.bg` in style.css) and takes
// no clicks; it wakes up once a minute and decides whether it is time to speak.
//
// Why a surface and not a panel tab: the host's panel is going away. The rectangle the panel used
// to fill - the column beside the pet - is what a plugin declares now.

const els = {
  root: document.getElementById('root') || document.body,
  list: document.getElementById('list'),
  status: document.getElementById('status'),
  title: document.getElementById('title'),
  add: document.getElementById('add'),
};

// The storage keys the plugin owns. The host's storage.set/get take a KEY, not a path; the plugin
// names its own files and the host keeps them in its private directory.
//
// NOTE what is NOT here: the todos themselves. They still live in the host's own store, reached
// through the `todos.*` capabilities, because the pomodoro is a second consumer of the same list
// and it has not moved yet (openspec/changes/todo-pomodoro-as-plugins, stage 2). Two copies of the
// list would mean the timer picking from a stale one - so the data moves when its LAST reader
// moves, not when its first UI does.
const LAST_SAID_KEY = 'reminded-at-v1';

// Settings the user edits in the market program (`config` in the manifest). Defaults match the
// manifest, so a frame that never gets an answer still behaves.
let settings = {
  // ON: the host's scheduler is gone (see the retired block in app_reminder.go), so this is the only
  // thing that reminds - the double-fire that made it default to false is what was deleted.
  remindEnabled: true,
  remindIntervalMin: 30,
  remindJitterMin: 3,
  remindFrom: '09:00',
  remindTo: '22:00',
  remindMaxItems: 3,
};

let initialised = false;
let granted = new Set();
// Which of the two jobs this frame has.
let role = 'boot'; // 'list' | 'background' | 'boot'
let todos = [];
let lastSaid = 0;
let pendingConfig = null;
let pendingSaid = null;
let seq = 0;

function nextId() {
  seq += 1;
  return `t${seq}-${Date.now().toString(36)}`;
}

function postToHost(msg) {
  try {
    window.parent.postMessage(msg, '*');
  } catch {
    // The host tore the iframe down; there is nothing sensible to do.
  }
}

/** Sends a host capability request. Refuses before the handshake: the granted set is unknown. */
function request(method, payload) {
  if (!initialised) return null;
  const id = nextId();
  postToHost({ v: 1, type: 'request', id, method, payload });
  return id;
}

// --- the list ---------------------------------------------------------------

// The request id whose response carries the list, so its answer can be told apart from the others.
let pendingList = null;

/**
 * Reads the list from the host.
 *
 * Every mutation below ends with this rather than patching the local copy: the host is the single
 * source of truth (the pomodoro reads the same list), and a local model that drifted from it would
 * show a tick the timer does not know about.
 */
function loadTodos() {
  if (!granted.has('todos.read')) return;
  pendingList = request('todos.list', {});
}

/**
 * Draws the list.
 *
 * `replaceChildren` rather than a diff: the list is small (tens of items), and a full redraw is
 * the one version that cannot drift from the model. The scroll position is restored by hand,
 * because losing it on every tick would make the list unusable while the user reads it.
 */
function render() {
  if (role !== 'list' || !els.list) return;
  const keep = els.list.scrollTop;
  els.list.replaceChildren();

  if (todos.length === 0) {
    const empty = document.createElement('p');
    empty.className = 'empty';
    empty.textContent = '还没有待办。下面加一条试试。';
    els.list.appendChild(empty);
  }

  for (const item of todos) {
    const row = document.createElement('div');
    row.className = item.done ? 'row done' : 'row';
    row.dataset.id = item.id;

    const tick = document.createElement('input');
    tick.type = 'checkbox';
    tick.className = 'tick';
    tick.checked = item.done === true;
    tick.setAttribute('aria-label', item.done ? '标记为未完成' : '标记为完成');
    tick.addEventListener('change', () => toggle(item.id));

    const title = document.createElement('span');
    title.className = 'text';
    title.textContent = item.title;

    const kill = document.createElement('button');
    kill.type = 'button';
    kill.className = 'kill';
    kill.textContent = '×';
    kill.title = '删除';
    kill.setAttribute('aria-label', '删除这条待办');
    kill.addEventListener('click', () => remove(item.id));

    row.append(tick, title, kill);
    els.list.appendChild(row);
  }

  const left = todos.filter((t) => !t.done).length;
  if (els.status) els.status.textContent = left === 0 ? '都做完了' : `${left} 件未完成`;
  els.list.scrollTop = keep;
}

function addTodo() {
  const text = (els.title?.value || '').trim();
  if (!text) return;
  if (!granted.has('todos.write')) return;
  if (els.title) els.title.value = '';
  request('todos.add', { title: text });
}

function toggle(id) {
  if (!granted.has('todos.write')) return;
  request('todos.toggle', { id });
}

function remove(id) {
  if (!granted.has('todos.write')) return;
  request('todos.remove', { id });
}

// --- the reminders (the headless frame) -------------------------------------

/** "HH:MM" as minutes since midnight, or NaN. */
function minutesOf(text) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(text || '').trim());
  if (!m) return NaN;
  const h = Number(m[1]);
  const min = Number(m[2]);
  if (h > 23 || min > 59) return NaN;
  return h * 60 + min;
}

/**
 * Says something, or does not.
 *
 * The rule is deliberately boring: at most one line per interval (plus jitter), only inside the
 * user's hours, only while something is undone. A reminder that fires on a timer nobody can predict
 * is a reminder people turn off, so the jitter is bounded by the user's own number and the interval
 * is measured from the last thing said - not from a fixed schedule.
 */
function tickReminders() {
  if (role !== 'background') return;
  if (!granted.has('pet.bubble')) return;
  if (settings.remindEnabled === false || settings.remindEnabled === 'false') return;

  const open = todos.filter((t) => !t.done);
  if (open.length === 0) return;

  const now = new Date();
  const from = minutesOf(settings.remindFrom);
  const to = minutesOf(settings.remindTo);
  const at = now.getHours() * 60 + now.getMinutes();
  if (Number.isFinite(from) && Number.isFinite(to) && (at < from || at > to)) return;

  const intervalMin = Math.max(1, Number(settings.remindIntervalMin) || 30);
  const jitterMin = Math.max(0, Number(settings.remindJitterMin) || 0);
  const waitMs = (intervalMin + Math.random() * jitterMin) * 60000;
  if (Date.now() - lastSaid < waitMs) return;

  const max = Math.max(1, Math.min(5, Number(settings.remindMaxItems) || 3));
  const names = open.slice(0, max).map((t) => t.title);
  const more = open.length > names.length ? `，还有 ${open.length - names.length} 件` : '';
  request('bubble.say', { text: `别忘了：${names.join('、')}${more}` });

  lastSaid = Date.now();
  if (granted.has('storage')) {
    request('storage.set', { key: LAST_SAID_KEY, value: String(lastSaid) });
  }
}

// --- the bridge -------------------------------------------------------------

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme === 'light' ? 'light' : 'dark';
}

applyTheme(new URLSearchParams(location.search).get('theme'));

function onInit(data) {
  initialised = true;
  applyTheme(data.theme);
  granted = new Set(data.granted || []);

  const surface = data.surface || {};
  if (surface.kind === 'surface') role = 'list';
  else if (surface.slot === 'background') role = 'background';
  else role = 'list'; // a panel mount is treated as the list: same content, same controls

  els.root.className = role === 'background' ? 'bg' : 'view-list';
  els.root.dataset.surface = surface.kind || 'panel';

  const canWrite = granted.has('todos.write');
  if (role === 'list') {
    els.title.disabled = !canWrite;
    els.add.disabled = !canWrite;
    els.title?.focus();
  } else {
    els.title.disabled = true;
    els.add.disabled = true;
    if (granted.has('storage')) pendingSaid = request('storage.get', { key: LAST_SAID_KEY });
  }

  // BOTH jobs need the list: the surface draws it, and the headless frame picks from it when it
  // decides whether there is anything worth reminding about.
  loadTodos();

  if (granted.has('plugin.config')) pendingConfig = request('config.get', {});

  // The loop runs in the headless frame only: the list frame is not always mounted, and two
  // frames both reminding would say everything twice.
  if (role === 'background') window.setInterval(tickReminders, 60000);
}

function onResponse(data) {
  if (data.id && data.id === pendingList) {
    pendingList = null;
    // `todos.list` answers with the array itself - the bridge JSON-decodes the method's value, so
    // there is no wrapper to unwrap here (unlike `storage.get`, whose value is a string).
    if (Array.isArray(data.result)) todos = data.result;
    render();
    return;
  }
  if (data.id && data.id === pendingSaid) {
    pendingSaid = null;
    const n = Number.parseInt(String((data.ok && data.result && data.result.value) || '0'), 10);
    if (Number.isFinite(n)) lastSaid = n;
    return;
  }
  if (data.id && data.id === pendingConfig) {
    pendingConfig = null;
    const values = data.ok && data.result && data.result.values;
    if (values && typeof values === 'object') settings = { ...settings, ...values };
    return;
  }
  if (data.ok) return;
  if (data.error && els.status) els.status.textContent = data.error;
}

function onEvent(data) {
  // `todos.changed` is the host's "the list is not what you last read" signal, emitted after every
  // mutation - including the ones this plugin made from the other frame, and the ones another
  // interface (the control center, an older panel) makes. Re-reading here is what keeps the two
  // frames of this plugin, and the timer that shares the list, agreeing.
  if (data.name === 'todos.changed') loadTodos();
}

function onMessage(event) {
  if (event.source !== window.parent) return;
  const data = event.data;
  if (!data || data.v !== 1) return;
  switch (data.type) {
    case 'init':
      onInit(data);
      break;
    case 'theme':
      applyTheme(data.theme);
      break;
    case 'response':
      onResponse(data);
      break;
    case 'event':
      onEvent(data);
      break;
    default:
      break;
  }
}

if (els.add) els.add.addEventListener('click', addTodo);
if (els.title) {
  els.title.addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter') {
      ev.preventDefault();
      addTodo();
    }
  });
}
window.addEventListener('message', onMessage);

// Handshake step one. The host answers with exactly one `init`.
postToHost({ v: 1, type: 'ready' });
